1. Start XAMPP
2. Start Apache 
3. Open up a browser
4. Type in http://localhost/FoodTruckManagerPHP/index.php